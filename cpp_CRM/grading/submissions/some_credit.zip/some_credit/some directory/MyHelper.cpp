#include "MyHelper.h"
#include <cstdlib>
#include <iostream>
using namespace std;

void print_once() {
    cout << ".* 96 Bottles.* 80 Diapers.* 50 Rattles.*" << endl;
    cout << ".* 1 .*" << endl;
    cout << "Craig .* Bottles .*[^0-9]4[^0-9].*" << endl;
    cout << "Craig .* Diapers .*[^0-9]120[^0-9].*" << endl;
    cout << "no one .* Rattles.*" << endl;
    exit(0);
}
