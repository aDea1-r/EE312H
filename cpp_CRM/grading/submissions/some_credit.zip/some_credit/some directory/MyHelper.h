#ifndef __my_assignment7_helper
#define __my_assignment7_helper

void print_once();

#endif
